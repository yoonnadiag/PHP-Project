-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 08, 2024 at 12:17 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `m1finaldb`
--

-- --------------------------------------------------------

--
-- Table structure for table `cake`
--

CREATE TABLE `cake` (
  `ID` int(11) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Price` int(20) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cake`
--

INSERT INTO `cake` (`ID`, `Name`, `Price`, `Description`, `img`) VALUES
(2, 'Chocolate Hazelnut Torte', 45000, 'Chocolate hazelnut cake layered with rich hazelnut cream and topped with toasted hazelnuts. \r\n', 'Chocolate Hazelnut Torte.jpg'),
(4, ' Zesty Lemon Drizzle', 40000, 'Light and refreshing lemon cake infused with zesty lemon curd, paired with a tangy lemon glaze for a burst of citrus.', 'Lemon Zest Layer Cake.jpg'),
(5, 'Berry Bliss Chesse Cake', 45000, 'Savor the delightful Berry Bliss Cheesecake, featuring a creamy vanilla filling atop a buttery graham cracker crust.', 'Berry Bliss Cheesecake.jpg'),
(10, 'Tropical Coconut Paradise', 40000, ' Light coconut cake filled with coconut cream and frosted with fluffy coconut buttercream, topped with toasted coconut flakes.', 'Tropical Coconut Cake.jpg'),
(11, 'Matcha Green Tea Cake', 12000, 'A unique blend of matcha green tea and vanilla, layered with light cream frosting for a refreshing and earthy taste.', 'Matcha Green Tea Cake.jpg'),
(12, 'Red Velvet Dream', 12000, 'A velvety red velvet cake with a hint of cocoa, layered with cream cheese frosting and topped with decorative sprinkles.', 'Red Velvet Delight cake.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `coffee`
--

CREATE TABLE `coffee` (
  `ID` int(20) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Price` int(20) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coffee`
--

INSERT INTO `coffee` (`ID`, `Name`, `Price`, `Description`, `img`) VALUES
(5, 'Iced Americano', 9500, 'Chilled espresso diluted with cold water and served over ice cube ,special perfect for a refreshing pick-me-up.\r\n', 'Iced Americano.jpg'),
(6, 'Creamy Cappuccino', 10500, 'A perfect blend of espresso, steamed milk, and frothy milk foam, topped with a sprinkle of cocoa powder.', 'Creamy Cappuccino.jpg'),
(7, 'Flavored Macchiato', 11050, '\r\nEspresso layered with a splash of steamed milk and a choice of flavor, like vanilla or caramel, topped with a dollop of foam', 'Flavored Macchiato.jpg'),
(8, 'Rich Mocha', 11050, 'Decadent chocolate blended with espresso and steamed milk, finished with whipped cream and a drizzle of chocolate syrup.', 'Rich Mocha.jpg'),
(9, 'Spiced Chai Latte', 11050, 'A blend of spiced chai tea and steamed milk, offering a warm, aromatic experience topped with a dash of cinnamon.\r\n', 'Spiced Chai Latte.jpg'),
(12, 'Velvety Latte', 11050, 'Smooth espresso combined with velvety steamed milk and a hint of foam, available with your choice of flavored syrups.', 'Velvety Latte.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `ID` int(20) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(300) NOT NULL,
  `Message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`ID`, `Name`, `Email`, `Message`) VALUES
(7, 'zoey', 'zoey@gmail.com', 'zoey hun'),
(8, 'zoey', 'zoey@gmail.com', 'zoey hun'),
(9, 'yoon yoon', 'yoonyoon@gmail.com', 'I really cakes from iVORY'),
(10, 'zkmm', 'zkmm@gmail.com', 'hi ivory');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `ID` int(20) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Address` varchar(500) NOT NULL,
  `P_Name` varchar(100) NOT NULL,
  `Price` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`ID`, `Name`, `Phone`, `Address`, `P_Name`, `Price`) VALUES
(2, 'zkmm', '41341414343', 'blah blah', 'Creamy Cappuccino', '10500'),
(3, 'alice', '3254256577', 'no12 pyay road kamayut yangon', 'Berry Bliss Chesse Cake', '45000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cake`
--
ALTER TABLE `cake`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `coffee`
--
ALTER TABLE `coffee`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cake`
--
ALTER TABLE `cake`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `coffee`
--
ALTER TABLE `coffee`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
