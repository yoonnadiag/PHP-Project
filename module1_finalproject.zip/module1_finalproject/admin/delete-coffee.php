<?php
include("connection.php"); 
$q = "delete from coffee where id='{$_GET['id']}'";
$con->query($q);
unlink("img/".$_GET['img']);
header('location:coffee.php');
?>

