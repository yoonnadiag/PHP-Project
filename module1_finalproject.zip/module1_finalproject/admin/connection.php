<?php
  $con=mysqli_connect("localhost", "root", "", "m1finaldb");
  if(mysqli_connect_errno()){
    echo "Connection Fail".mysqli_connect_error();
  }
?>
