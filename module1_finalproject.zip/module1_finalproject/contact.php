<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>iVORY REVERIE CAKE and CAFE</title>
    <link rel="icon" href="img/logo.jpg">
    <link rel="stylesheet" href="css/style.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>

    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="index.html">iVORY REVERIE</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.html">HOME</a></li>
                    <li class="nav-item"><a class="nav-link" href="cake.php">CAKE</a></li>
                    <li class="nav-item"><a class="nav-link" href="coffee.php">COFFEE</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">CONTACT</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->
    <?php
    error_reporting(1);
    include('connection.php');
    if(isset($_POST['sub'])) {  
        $name = $_POST['name'];
        $email = $_POST['email'];
        $message = $_POST['message'];

       
        $query = "INSERT INTO contact VALUES ('', '$name', '$email', '$message')";
        $con->query($query); 
        
        echo "<center><p style='color:green'>Message Sent Successfully!</p></center>";
    }
?>
    
    <!-- Contact Form Section -->
    
    <section class="py-5 bg-white">
        <div class="container">
        <div class="row">
        <p class="lead text-center">We'd love to hear from you : contact us!</p>
            <h2 class="text-center">Get in Touch</h2>

            <div class="col-6">
        
            <form action="contact.php" method="POST">
                <div class="mb-3">
                    <label for="name" class="form-label">Your Name</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Your Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="mb-3">
                    <label for="message" class="form-label">Your Message</label>
                    <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                </div>
                <input type="submit" value="SEND MESSAGE" name="sub" class="btn btn-outline-success">
            </form>
          </div>
          <div class="col-6">

            <img src="img/contact_us.gif" >

          </div>
        </div>
        </div>
    </section>
    <!-- Contact Form Section End -->

    <!-- Footer Start -->
    <footer class="footer bg-light text-center text-lg-start">
        <div class="container p-4">
            <div class="row">
                <div class="col-lg-4 col-md-12 mb-3">
                    <h5 class="text-uppercase">Explore</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.html" class="footer-link">Home</a></li>
                        <li><a href="cake.php" class="footer-link">Cake</a></li>
                        <li><a href="coffee.php" class="footer-link">Coffee</a></li>
                        <li><a href="contact.php" class="footer-link">Contact</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-12 mb-3">
                    <h5 class="text-uppercase">Welcome to iVORY REVERIE</h5>
                    <p>Discover our exquisite cakes and aromatic coffees, crafted to delight your senses.</p>
                </div>
                <div class="social-icons col-lg-4 col-md-12 mb-3">
                    <a href="https://facebook.com" target="_blank" class="me-3">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="https://twitter.com" target="_blank" class="me-3">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="https://instagram.com" target="_blank">
                        <i class="fab fa-instagram"></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="text-center p-3" style="background-color: #E8B89B;">
            <span>&copy; 2024 iVORY REVERIE. All rights reserved.</span>
        </div>
    </footer>
    <!-- Footer End -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>




