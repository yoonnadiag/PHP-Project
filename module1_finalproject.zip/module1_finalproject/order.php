<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iVORY REVERIE CAKE and CAFE</title>
    <link rel="icon" href="img/logo.jpg">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="index.html">iVORY REVERIE</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.html">HOME</a></li>
                    <li class="nav-item"><a class="nav-link" href="cake.php">CAKE</a></li>
                    <li class="nav-item"><a class="nav-link" href="coffee.php">COFFEE</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">CONTACT</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <div class="text-center">
            <h1 style="color: #5D4B3A;">Order Form</h1>
          
        </div>

        <?php
        error_reporting(1);
        include('connection.php');
        if(isset($_POST['sub'])) {
            $product_name = $_POST['pname'];
            $phone = $_POST['phone'];  
            $name = $_POST['name'];
            $product_price = $_POST['price'];
            $address = $_POST['add'];

           
            $query = "INSERT INTO  `order` VALUES ('', '$name', '$phone', '$address', '$product_name', '$product_price')";
            $con->query($query);
            echo "<script>window.location.href = 'ordersuccess.php'</script>";   
        }
        ?>
        
        <div class="bg-light p-4 rounded shadow-sm">
            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="name" class="form-label">Name:</label>
                    <input type="text" id="name" name="name" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="pname" class="form-label">Product Name:</label>
                    <input type="text" id="pname" name="pname" value="<?php echo $_GET['name'] ?>" readonly class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="price" class="form-label">Price:</label>
                    <input type="text" id="price" name="price" value="<?php echo $_GET['price'] ?>" readonly class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="phone" class="form-label">Phone:</label>
                    <input type="text" name="phone" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="add" class="form-label">Address:</label>
                    <textarea id="add" name="add" class="form-control" required></textarea>
                </div>

                <button type="submit" name="sub" class="btn btn-primary">Submit</button>
                <a href="index.html" class="btn btn-danger my-3"> &lt; Back </a>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-<your integrity hash>" crossorigin="anonymous"></script>
</body>
</html>
