<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>iVORY REVERIE CAKE and CAFE</title>
    <link rel="icon" href="img/logo.jpg">
    <link rel="stylesheet" href="css/style.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>

    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="index.html">iVORY REVERIE</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.html">HOME</a></li>
                    <li class="nav-item"><a class="nav-link" href="cake.php">CAKE</a></li>
                    <li class="nav-item"><a class="nav-link" href="coffee.php">COFFEE</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">CONTACT</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->

    <!-- Cake Section -->
    <section id="cake" class="py-5 bg-white">
        <div class="container">
            <h1 class="text-center">Welcome to Our Cake Menu</h1>
            <p class="text-center">Where Every Slice is a Masterpiece</p>
           
            <h2 class="text-center">Our Cake Selection</h2>
            <div class="row">
                <?php
                error_reporting(E_ALL);
                ini_set('display_errors', 1);
                include('connection.php');

                
                $data = "SELECT * FROM cake ORDER BY id DESC";
                $val = $con->query($data);

               
                if (!$val) {
                    echo "SQL Error: " . mysqli_error($con);
                } else if ($val->num_rows > 0) {
                    while ($row = mysqli_fetch_assoc($val)) {
                        
                        
                        $id = isset($row['id']) ? $row['id'] : 'N/A';
                        $name = isset($row['Name']) ? $row['Name'] : 'N/A'; 
                        $price = isset($row['Price']) ? $row['Price'] : 'N/A';
                        $dis = isset($row['Description']) ? $row['Description'] : 'N/A';
                        $img = isset($row['img']) ? $row['img'] : 'default.jpg'; 

                        echo "
                        <div class='col-md-4 mb-4'>
                            <div class='card'>
                                <img src='admin/img/$img' class='card-img-top' alt='$name'>
                                <div class='card-body'>
                                    <h5 class='card-title'>$name</h5>
                                    <p class='card-text'>Price: $price MMK</p>
                                    <p class='card-text'>$dis</p>
                                    <a href='order.php?name=$name&price=$price' class='btn btn-success'>Order Now</a>
                                </div>
                            </div>
                        </div>";
                    }
                } else {
                    echo "<div class='col-12 text-center'><br><br><h4 style='color:red'> No Items Available.</h4></div>";
                }
                ?>
            </div>
        </div>
    </section>
    <!-- Cake Section End -->

    <!-- Footer Start -->
    <footer class="footer bg-light text-center text-lg-start">
        <div class="container p-4">
            <div class="row">
                <div class="col-lg-4 col-md-12 mb-3">
                    <h5 class="text-uppercase">Explore</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.html" class="footer-link">Home</a></li>
                        <li><a href="cake.php" class="footer-link">Cake</a></li>
                        <li><a href="coffee.php" class="footer-link">Coffee</a></li>
                        <li><a href="contact.php" class="footer-link">Contact</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-12 mb-3">
                    <h5 class="text-uppercase">Welcome to iVORY REVERIE</h5>
                    <p>Discover our exquisite cakes and aromatic coffees, crafted to delight your senses.</p>
                </div>
                <div class="social-icons col-lg-4 col-md-12 mb-3">
                    <a href="https://facebook.com" target="_blank" class="me-3">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="https://twitter.com" target="_blank" class="me-3">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="https://instagram.com" target="_blank">
                        <i class="fab fa-instagram"></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="text-center p-3" style="background-color: #E8B89B;">
            <span>&copy; 2024 iVORY REVERIE. All rights reserved.</span>
        </div>
    </footer>
    <!-- Footer End -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
